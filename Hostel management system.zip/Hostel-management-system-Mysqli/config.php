<?php 
error_reporting(1);
$con = mysqli_connect("localhost","root","","hostel");

?>