<center><h1>Campus Drive</h1></center>

<center>Panipat (St.Joseph's College) - <b>Accenture</b> - 17th July '14<br><br>

Allahabad (IIIT Alhbd) - <b>Wipro</b> - 28th July '14<br><br>

Lucknow (IET Lucknow) - <b>TCS</b> - 8th august '14<br><br>

Noida (JSS AMCET)- <b>Syntel</b> - 18th Aug '14</center>